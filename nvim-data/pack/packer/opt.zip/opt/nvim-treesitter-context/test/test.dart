@Deprecated('')
abstract 
class User 
    extends 
      Object {
  User(this.age);
  int age;












  void printAge() {
  













    print(age);
  }

}

String(
  int magicalNumber,
) {
  if (magicalNumber == "69"
      // --
      ||
      magicalNumber == "420") {
    return 'pretty nice';




  } else if (magicalNumber == "420" // -
      &&
      magicalNumber == "69") {






















    return 'pretty high';
  }
  return 'just decent';
}


void catching() {
  try 
    // --
  {














  } catch (e) {










  } finally {












  }
}

void foring() {
  for (int i = 0; // -
        i < 10;
        i++) {














  }

  while (true // -- 
  == false) {


















}

  do {














} while (true);
}

extension ext 
on int {









}
