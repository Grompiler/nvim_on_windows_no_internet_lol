package mymod;

import stuff1;
import stuff2;

@class_annot_1
@class_annot_2
public class MyClass {




    @method_annot_1
    @method_annot_2
    public void my_method(int param) {




        if (true) {




            for (int i = 0; i < 10; i++) {
                



                for (int var : iterable) {
                    



                    System.



                        out.println("a message");
                }
            }
        }
    }
}
