# H1
<!-- <- @markup.heading.1 -->

## H2
<!-- <- @markup.heading.2 -->

- Item 1
- Item 2
<!-- <- @markup.list -->

1. Item 1
2. Item 2
<!-- <- @markup.list -->

----![image_description](https://example.com/image.jpg "awesome image title")
<!--  ^ @markup.link.label                                                    -->
<!--                              ^ @markup.link.url                              -->
<!--                                                      ^ @markup.link.label  -->
<!--^ @markup.link                                                 -->
<!-- ^ @markup.link                                                -->
<!--                    ^ @markup.link                             -->

[link_text](#local_reference "link go brr...")
<!-- ^ @markup.link.label                                                     -->
<!--                 ^ @markup.link.url                                           -->
<!--                            ^ @markup.link.label                            -->
<!-- <- @markup.link                                               -->
<!--       ^ @markup.link                                          -->
