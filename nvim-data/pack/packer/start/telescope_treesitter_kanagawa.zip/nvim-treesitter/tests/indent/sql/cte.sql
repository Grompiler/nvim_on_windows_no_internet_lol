with data as (
    select
        a,
        b
    from tab
)
select * from data;
