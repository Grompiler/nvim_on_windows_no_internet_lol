return {
	s("trig2", fmt("this {} also works :))", { i(1) })),
}

-- don't remove, depended on by "lua-loader respects include/exclude"!!
