namespace hello_world
{
    interface IInterface
    {









    }

    public enum Direction
    {
        Left,
        Right,
        Up,
        Down



    }

    class Cls
    {
        // Constructor
        public Cls ()
        {












        }

        // Destructor
        ~Cls()
        {












        }
    }

    record Record
    {














    }

    record struct RecordStruct
    {
















    }

    public struct Test
    {
        public void Test1()
        {
            if (true)
            {













            }
            else
            {
                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine();
            }
            var arr = new[] { 1, 2, 3 };

            foreach (var item in arr)
            {







            }

            for (int i = 0; i < arr.Length; i++)
            {
                try
                {
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                }
                catch
                {














                }
                finally
                {















                }
            }
        }

        int Switch(int key)
        {
            switch (key)
            {
                case 0:













                    return 1;
                case 1:








                    return 2;
                case 2:






                    return 12;
                case 3:
                    return 444;
                case 4:
                case 5:
                case 6:
                case 7:
                case 8:
                case 9:
                case 10:
                case 11:
                case 12:
                case 13:
                case 14:
                case 15:
                case 16:
                case 17:
                case 18:
                case 19:
                case 20:
                case 21:
                case 22:

                    
















                    return 1234444;
                default: throw new Exception();

            }















        }
    }
}


































