local function foo()

  local function bar()



  end

  local function baz()



  end

end
