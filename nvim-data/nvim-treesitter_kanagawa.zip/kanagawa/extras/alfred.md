# Alfred Themes

- [wave](https://www.alfredapp.com/extras/theme/H6Cwmm2rG1/)
