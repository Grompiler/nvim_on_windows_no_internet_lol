<template>
  Foo
</template>
