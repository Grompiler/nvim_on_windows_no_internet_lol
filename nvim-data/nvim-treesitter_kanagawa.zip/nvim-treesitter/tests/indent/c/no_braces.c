int foo(int x) {
    if (x > 10)
        return 10;
    else
        return x;

    while (1)
        x++;

    for (int i = 0; i < 3; ++i)
        x--;
}

