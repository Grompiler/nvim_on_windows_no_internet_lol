return {
	parse("aaaa", "lua"),
}
