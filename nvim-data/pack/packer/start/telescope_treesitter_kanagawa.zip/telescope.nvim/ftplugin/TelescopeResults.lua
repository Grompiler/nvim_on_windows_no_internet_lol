-- Don't have scrolloff, it makes things weird.
vim.opt_local.scrolloff = 0
vim.opt_local.scrollbind = false

vim.opt_local.signcolumn = "no"
