struct Bert {
    int *f1;
    // comment
    int *f2;
    // comment
    // comment
    // comment
    // comment
    // comment
};

typedef enum {
  E1,
  E2,
  E3
  // comment
  // comment
  // comment
  // comment
  // comment
  // comment
} Myenum;

int main(int arg1,
         char **arg2,
         char **arg3
         )
{

  if (arg1 == 4
      && arg2 == arg3) {

    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    for (int i = 0; i < arg1; i++) {
      // comment
      // comment
      // comment
      // comment
      while (1) {
        // comment
        // comment
        // comment
        // comment
        // comment
      }

      do {
        // comment
        // comment
        // comment
        // comment
        // comment

      } while (1);
      // comment
      // comment
      // comment
      // comment
      // comment
    }

  } else if (arg1 == 4) {
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment

  } else {
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment
    // comment

  }

  switch (arg1) {
    // comment
    // comment
    case 0:
      // comment
      // comment
      // comment
      // comment
      // comment
      // comment
      // comment
      // comment
      // comment
      // comment
      break;
    case 1: {
      // comment
      // comment
      // comment
      // comment
      // comment
      // comment
      // comment
      // comment
      // comment
      // comment
    } break;
  }
}
