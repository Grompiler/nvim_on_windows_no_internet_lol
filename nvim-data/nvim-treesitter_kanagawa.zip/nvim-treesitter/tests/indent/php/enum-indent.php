<?php

enum Test: int
{
