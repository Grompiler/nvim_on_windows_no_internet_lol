enum foo {
    A = 1,
    B,
    C,
};
