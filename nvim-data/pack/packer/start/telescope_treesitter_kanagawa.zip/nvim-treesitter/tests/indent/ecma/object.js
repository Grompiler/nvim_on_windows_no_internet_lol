const obj = {
  a: 1,
  b: "2",
  ["c"]: `three`
}
